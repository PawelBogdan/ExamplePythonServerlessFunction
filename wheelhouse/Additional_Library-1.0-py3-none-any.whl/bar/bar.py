
def f():
    return "FOO BAR!!!"
